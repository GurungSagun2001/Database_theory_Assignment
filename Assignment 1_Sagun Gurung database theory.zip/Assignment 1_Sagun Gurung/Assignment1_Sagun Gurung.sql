create database employeeDB;

create table Employee (EMP_NUM INT unique not null, EMP_LNAME varchar(15) not null,EMP_FNAME varchar(15) not null,EMP_INITIAL char(1) not null,
EMP_HIREDATE DATE not null, JOB_CODE int not null);



insert into Employee values (101,'News','John','G','08-Nov-00',502);

insert into Employee values (102,'Senior','David','H','12-Jul-89',501);
insert into Employee values (103,'Arbough','June','E','01-Dec-96',500);
insert into Employee values (104,'Ramoras','Anne','K','15-Nov-87',501);
insert into Employee values (105,'Johnson','Alice','K','01-Feb-93',502);
insert into Employee values (106,'Smithfield','William',' ','22-Jun-04',500);
insert into Employee values (107,'Alonzo','Maria','D','10-Oct-93',500);
insert into Employee values (108,'Washington','Ralph','B','22-Aug-91',501);
insert into Employee values (109,'Smith','Larry','W','18-Jul-97',501);


update Employee /*Updating the job code of employee 107 from 500 to 501 */
set JOB_CODE = 501 
where EMP_NUM=107;

update Employee /*Updating the job code of employee 107 from 501 to 500 */
set JOB_CODE = 500 
where EMP_NUM=107;

select * from Employee where JOB_CODE = 502;   /* This query will allow us to print the attributes which has job code '502'. */

delete from Employee			/*Using 'WHERE' clause with logical operator 'AND' to delete the row*/
WHERE EMP_HIREDATE = '22-Jun-04' AND JOB_CODE = 500;		/*The row with the name William Smithfield has been deleted.*/

		/*Adding columns using alter.*/
alter table Employee add EMP_PCT INT , PROJ_NUM INT ;
									
		/*Entering project number 18 to all employee whose job code in 500.*/		
update Employee set PROJ_NUM = 18 WHERE JOB_CODE = 500; 

		/*Entering project number 25 to all employee whose job code in 502.*/		
update Employee set PROJ_NUM = 25 WHERE JOB_CODE = 502; 

	/*Changing project number 14 to all employee who were hired before January 1, 1994 and job code is at least 501.*/		
update Employee set PROJ_NUM = 14 WHERE EMP_HIREDATE<'01-Jan-94' AND JOB_CODE>=501; 

Select * from Employee;
		/*Selecting employees first name, last name, job code and hire date whose first name starts with letter �A�.*/
select EMP_FNAME,EMP_LNAME,JOB_CODE,EMP_HIREDATE 
FROM Employee WHERE  EMP_FNAME LIKE 'A%';


		/*Inserting a new column �Salary� into this table and insert the data values for all the table records.*/
alter table Employee add Salary INT;
update Employee set Salary = 180 WHERE EMP_NUM = 101;
update Employee set Salary = 500 WHERE EMP_NUM = 102;
update Employee set Salary = 250 WHERE EMP_NUM = 103;
update Employee set Salary = 350 WHERE EMP_NUM = 104;
update Employee set Salary = 210 WHERE EMP_NUM = 105;
update Employee set Salary = 200 WHERE EMP_NUM = 106;
update Employee set Salary = 450 WHERE EMP_NUM = 107;
update Employee set Salary = 300 WHERE EMP_NUM = 108;
update Employee set Salary = 400 WHERE EMP_NUM = 109;


		/*employee with the highest salary*/
SELECT * FROM Employee  
	WHERE Salary = (SELECT MAX(Salary) FROM Employee);

Select * from Employee;
	/*number of employees in department 500 and 502.*/
SELECT COUNT(*) AS employee_count
FROM Employee
WHERE JOB_CODE IN (500, 502);


		/*Getting the count of employees hired year-wise*/
select EMP_HIREDATE,count(*) AS employee_count FROM Employee group by EMP_HIREDATE order by EMP_HIREDATE;

			/*There was no name with 'onz' in FNAME so i got it from LNAME. */
select * from Employee where EMP_LNAME LIKE '%onz%';


/*Employees who joined in july 1989*/
select * from Employee where EMP_HIREDATE>='01-Jul-89' and EMP_HIREDATE <='30-jul-89';




